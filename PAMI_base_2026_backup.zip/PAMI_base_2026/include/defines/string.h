#ifndef _DEFINE_STRING_H_
#define _DEFINE_STRING_H_

#include <string>

using string_t = std::string;

#endif